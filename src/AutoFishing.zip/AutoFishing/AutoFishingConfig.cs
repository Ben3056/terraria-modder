using TerrariaModder.Core.Config;

namespace AutoFishing
{
    public class AutoFishingConfig : ModConfig
    {
        public override int Version => 1;

        [Client, Label("Enabled"), Description("Master toggle for all auto-fishing features.")]
        public bool Enabled { get; set; } = true;

        [Client, Label("Auto Cast"), Description("Automatically cast your fishing rod when holding it with no active bobber.")]
        public bool AutoCast { get; set; } = true;

        [Client, Label("Auto Reel"), Description("Automatically reel in when a fish bites.")]
        public bool AutoReel { get; set; } = true;

        [Client, Label("Skip Common Catches"), Description("Skip white/gray rarity normal catches (bite expires, no bait consumed). Quest fish, crates, accessories, and tools are always caught.")]
        public bool SkipCommonCatches { get; set; } = false;

        [Client, Label("Pull Delay (frames)"), Description("Frames to wait after detecting a bite before reeling in. 30 = 0.5 seconds."), Range(0, 120)]
        public int PullDelayFrames { get; set; } = 30;

        [Client, Label("Recast Delay (frames)"), Description("Frames to wait after reeling before recasting. 60 = 1 second."), Range(30, 600)]
        public int RecastDelayFrames { get; set; } = 120;

        [Client, Label("Auto Buff"), Description("Automatically drink fishing potions when buffs are missing or about to expire.")]
        public bool AutoBuffEnabled { get; set; } = true;

        [Client, Label("Auto Buff Only While Fishing"), Description("Only auto-buff when a fishing bobber is active.")]
        public bool AutoBuffOnlyWhenFishing { get; set; } = true;

        [Client, Label("Auto Fishing Potion"), Description("Auto re-drink Fishing Potion when buff expires.")]
        public bool AutoFishingPotion { get; set; } = true;

        [Client, Label("Auto Sonar Potion"), Description("Auto re-drink Sonar Potion when buff expires.")]
        public bool AutoSonarPotion { get; set; } = true;

        [Client, Label("Auto Crate Potion"), Description("Auto re-drink Crate Potion when buff expires.")]
        public bool AutoCratePotion { get; set; } = true;
    }
}

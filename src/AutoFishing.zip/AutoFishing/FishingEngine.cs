using System;
using Terraria;
using Terraria.ID;
using TerrariaModder.Core.Logging;

namespace AutoFishing
{
    /// <summary>
    /// Core fishing automation logic. Provides Harmony handlers for:
    /// - Prefix on Player.ItemCheck() — auto-cast and auto-reel via controlUseItem injection
    /// - Postfix on Player.Update(int) — auto-buff by re-drinking fishing potions on expiry
    /// </summary>
    public static class FishingEngine
    {
        private static ILogger _log;
        private static bool _initialized;

        // Temp item for rarity/category checks (reused to avoid allocation)
        private static Item _tempItem;

        // --- Fishing buff/potion IDs (verified in decomp) ---
        // BuffID: Fishing=121, Sonar=122, Crate=123
        // ItemID: FishingPotion=2354, SonarPotion=2355, CratePotion=2356
        private static readonly int[] FishingBuffIds = { 121, 122, 123 };
        private static readonly int[] FishingPotionItemIds = { 2354, 2355, 2356 };

        // --- State ---
        private static bool _justReeled;
        private static int _reelFrame;
        private static int _frameCounter;
        private static int _pullTimer;  // Frames until auto-reel fires (pulling delay)
        private static bool _initReady; // True once init delay has expired (set once)
        private static int _buffScanCooldown; // Throttle auto-buff scans (avoid spamming when no potions)

        public static void Initialize(ILogger log)
        {
            _log = log;

            try
            {
                _tempItem = new Item();
                _initialized = true;
                _log.Info("FishingEngine initialized with direct references");
            }
            catch (Exception ex)
            {
                _log.Error($"FishingEngine init failed: {ex.Message}");
            }
        }

        public static void Reset()
        {
            _justReeled = false;
            _reelFrame = 0;
            _frameCounter = 0;
            _pullTimer = 0;
            _initReady = false;
            _buffScanCooldown = 0;
        }

        /// <summary>
        /// Harmony Prefix on Player.ItemCheck().
        /// Injects controlUseItem + releaseUseItem = true to trigger vanilla cast/reel.
        /// </summary>
        public static void ItemCheckPrefix(Player __instance)
        {
            try
            {
                if (!_initialized || !Mod.Enabled) return;
                if (!_initReady) return;
                if (Main.gameMenu) return;

                int myPlayer = Main.myPlayer;
                if (__instance.whoAmI != myPlayer) return;

                // Check held item is a fishing rod
                Item heldItem = __instance.inventory[__instance.selectedItem];
                if (heldItem.fishingPole <= 0) return;

                _frameCounter++;

                // Handle pulling delay timer (counts down to 0, then triggers reel)
                if (_pullTimer > 0)
                {
                    // Suppress player input while waiting to pull — don't let manual click
                    // reel in a catch we haven't decided on yet
                    SuppressItemUse(__instance);

                    _pullTimer--;
                    if (_pullTimer == 0)
                    {
                        // Verify the bite is still active before reeling
                        if (HasActiveBite(myPlayer))
                        {
                            ForceItemUse(__instance);
                            _justReeled = true;
                            _reelFrame = _frameCounter;
                        }
                        // else: bite expired during delay, just let the bobber sit
                    }
                    return;
                }

                // Scan for active owned bobbers (check ALL — multi-bobber rods exist)
                bool hasBobber = false;
                bool hasBite = false;
                float caughtValue = 0f;

                for (int i = 0; i < 1000; i++)
                {
                    Projectile proj = Main.projectile[i];
                    if (!proj.active) continue;
                    if (!proj.bobber) continue;
                    if (proj.owner != myPlayer) continue;

                    hasBobber = true;

                    // Check bite state: ai[0]==0 (idle) + ai[1]<0 (biting) + localAI[1]!=0 (catch determined)
                    if (proj.ai[0] == 0f && proj.ai[1] < 0f && proj.localAI[1] != 0f)
                    {
                        hasBite = true;
                        caughtValue = proj.localAI[1];
                        break; // Found a bite — process it
                    }
                    // Don't break on non-bite bobbers — keep scanning for one that has a bite
                }

                if (hasBite)
                {
                    // Fish is biting — check skip filter first (works regardless of AutoReel)
                    if (Mod.SkipCommonCatches && caughtValue > 0f && !ShouldCatch((int)caughtValue))
                    {
                        // Filtered out — suppress player click so vanilla doesn't reel in,
                        // and let the bite expire naturally (no bait consumed)
                        SuppressItemUse(__instance);
                        return;
                    }

                    // Auto-reel if enabled
                    if (Mod.AutoReel)
                    {
                        // Start pulling delay timer
                        int delayFrames = Mod.PullDelayFrames;
                        if (delayFrames <= 1)
                        {
                            // Immediate reel
                            ForceItemUse(__instance);
                            _justReeled = true;
                            _reelFrame = _frameCounter;
                        }
                        else
                        {
                            _pullTimer = delayFrames;
                        }
                    }
                    // else: AutoReel off — player reels manually (filter already applied above)
                }
                else if (!hasBobber && Mod.AutoCast)
                {
                    // No bobber — auto-cast if cooldown elapsed
                    if (_justReeled)
                    {
                        int elapsed = _frameCounter - _reelFrame;
                        if (elapsed < Mod.RecastDelayFrames)
                            return;
                        _justReeled = false;
                    }

                    ForceItemUse(__instance);
                }
                // else: bobber exists but no bite — waiting, do nothing
            }
            catch (Exception ex)
            {
                Mod.LogDebug($"ItemCheck prefix error: {ex.Message}");
            }
        }

        /// <summary>
        /// Harmony Postfix on Player.Update(int).
        /// Auto-drinks fishing potions: applies missing buffs AND re-drinks on expiry.
        /// Only handles Fishing (121), Sonar (122), Crate (123) potions.
        /// </summary>
        public static void PlayerUpdatePostfix(Player __instance, int i)
        {
            try
            {
                if (!_initialized) return;

                // Tick init delay from postfix only (once per frame, avoids double-decrement)
                int myPlayer = Main.myPlayer;
                if (i == myPlayer)
                    Mod.TickInitDelay();

                if (!Mod.Enabled || !Mod.AutoBuffEnabled) return;
                if (!_initReady) return;
                if (i != myPlayer) return;
                if (Main.gameMenu) return;

                // If "only when fishing" is enabled, check for active bobber
                if (Mod.AutoBuffOnlyWhenFishing)
                {
                    if (!HasActiveBobber(myPlayer))
                        return;
                }

                // Throttle missing-buff scans to avoid spamming when no potions
                if (_buffScanCooldown > 0)
                {
                    _buffScanCooldown--;
                    return;
                }

                int[] buffTypes = __instance.buffType;
                int[] buffTimes = __instance.buffTime;
                bool anyMissing = false;

                // Check each managed fishing buff
                for (int idx = 0; idx < FishingBuffIds.Length; idx++)
                {
                    if (!IsBuffEnabled(idx)) continue;

                    int buffId = FishingBuffIds[idx];
                    int potionItemId = FishingPotionItemIds[idx];

                    // Find this buff in the player's active buffs
                    bool buffFound = false;
                    for (int b = 0; b < buffTypes.Length; b++)
                    {
                        if (buffTypes[b] == buffId)
                        {
                            buffFound = true;
                            // Re-drink when about to expire (time == 1 means it expires next frame)
                            if (buffTimes[b] == 1)
                            {
                                TryDrinkPotion(__instance, potionItemId, buffId);
                            }
                            break;
                        }
                    }

                    // Buff is completely absent — drink the first potion
                    if (!buffFound)
                    {
                        anyMissing = true;
                        TryDrinkPotion(__instance, potionItemId, buffId);
                    }
                }

                // If buffs were missing (no potions found), back off for 2 seconds
                // to avoid scanning inventory 60 times/sec for nothing
                if (anyMissing)
                    _buffScanCooldown = 120;
            }
            catch (Exception ex)
            {
                Mod.LogDebug($"Update postfix error: {ex.Message}");
            }
        }

        /// <summary>
        /// Called once when the init delay expires.
        /// Separated from IsReady() so it doesn't double-decrement from multiple patches.
        /// </summary>
        public static void SetInitReady()
        {
            _initReady = true;
        }

        /// <summary>
        /// Force item use by setting both controlUseItem and releaseUseItem to true.
        /// The vanilla guard at Player.cs:41981 requires both + itemAnimation == 0.
        /// </summary>
        private static void ForceItemUse(Player player)
        {
            if (player.itemAnimation != 0) return;
            player.controlUseItem = true;
            player.releaseUseItem = true;
        }

        /// <summary>
        /// Suppress player click input to prevent vanilla from reeling in a filtered catch.
        /// </summary>
        private static void SuppressItemUse(Player player)
        {
            player.controlUseItem = false;
        }

        /// <summary>
        /// Check if any owned bobber currently has an active bite.
        /// Used to verify bite hasn't expired during pull delay.
        /// </summary>
        private static bool HasActiveBite(int playerIndex)
        {
            try
            {
                for (int i = 0; i < 1000; i++)
                {
                    Projectile proj = Main.projectile[i];
                    if (!proj.active) continue;
                    if (!proj.bobber) continue;
                    if (proj.owner != playerIndex) continue;

                    if (proj.ai[0] == 0f && proj.ai[1] < 0f && proj.localAI[1] != 0f)
                        return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Manually trigger drinking all enabled fishing potions immediately.
        /// Called from the buff hotkey.
        /// </summary>
        public static void DrinkAllFishingPotions(Player player)
        {
            if (!_initialized) return;
            try
            {
                for (int idx = 0; idx < FishingBuffIds.Length; idx++)
                {
                    if (!IsBuffEnabled(idx)) continue;
                    TryDrinkPotion(player, FishingPotionItemIds[idx], FishingBuffIds[idx]);
                }
            }
            catch (Exception ex)
            {
                Mod.LogDebug($"DrinkAllFishingPotions error: {ex.Message}");
            }
        }

        /// <summary>
        /// Determine if a caught item should be reeled in based on filter settings.
        /// Returns false if the catch should be skipped.
        /// </summary>
        private static bool ShouldCatch(int itemType)
        {
            try
            {
                _tempItem.SetDefaults(itemType);

                // Always catch quest fish regardless of rarity filter
                if (_tempItem.questItem) return true;

                // Always catch accessories
                if (_tempItem.accessory) return true;

                // Always catch weapons/tools
                if (_tempItem.damage > 0) return true;

                // Always catch crates
                var isFishingCrate = ItemID.Sets.IsFishingCrate;
                if (isFishingCrate != null && itemType >= 0 && itemType < isFishingCrate.Length)
                {
                    if (isFishingCrate[itemType]) return true;
                }

                // Check rarity — skip white (0) and gray (-1) normal catches
                return _tempItem.rare > 0;
            }
            catch
            {
                return true; // On error, catch it
            }
        }

        /// <summary>
        /// Returns index into FishingBuffIds/FishingPotionItemIds, or -1 if not a fishing buff.
        /// </summary>
        private static int GetFishingBuffIndex(int buffId)
        {
            for (int i = 0; i < FishingBuffIds.Length; i++)
            {
                if (FishingBuffIds[i] == buffId) return i;
            }
            return -1;
        }

        /// <summary>
        /// Check if a specific fishing buff is enabled in config.
        /// Index: 0=Fishing, 1=Sonar, 2=Crate
        /// </summary>
        private static bool IsBuffEnabled(int index)
        {
            switch (index)
            {
                case 0: return Mod.AutoFishingPotion;
                case 1: return Mod.AutoSonarPotion;
                case 2: return Mod.AutoCratePotion;
                default: return false;
            }
        }

        /// <summary>
        /// Find a specific potion in inventory and consume it to re-apply the buff.
        /// Scans inventory slots 0-57 for matching potion item.
        /// </summary>
        private static void TryDrinkPotion(Player player, int potionItemId, int buffId)
        {
            try
            {
                Item[] inventory = player.inventory;
                // Scan all inventory slots (0-57, skipping slot 58 which is cursor item)
                for (int slot = 0; slot < 58; slot++)
                {
                    Item item = inventory[slot];
                    if (item.stack <= 0) continue;
                    if (item.type != potionItemId) continue;

                    // Found the potion — apply buff and consume
                    int buffTime = item.buffTime;
                    if (buffTime == 0) buffTime = 3600; // Default 1 minute in frames

                    player.AddBuff(buffId, buffTime, false);

                    if (item.consumable)
                    {
                        item.stack--;
                        if (item.stack <= 0)
                        {
                            item.TurnToAir();
                        }
                    }
                    return;
                }
                // No potion found — buff will expire naturally
            }
            catch (Exception ex)
            {
                Mod.LogDebug($"TryDrinkPotion error: {ex.Message}");
            }
        }

        /// <summary>
        /// Check if the local player has any active bobber projectile.
        /// </summary>
        private static bool HasActiveBobber(int playerIndex)
        {
            try
            {
                for (int i = 0; i < 1000; i++)
                {
                    Projectile proj = Main.projectile[i];
                    if (!proj.active) continue;
                    if (!proj.bobber) continue;
                    if (proj.owner == playerIndex) return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }
    }
}

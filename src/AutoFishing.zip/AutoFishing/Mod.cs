using System;
using System.Reflection;
using System.Threading;
using HarmonyLib;
using Terraria;
using TerrariaModder.Core;
using TerrariaModder.Core.Logging;

namespace AutoFishing
{
    public class Mod : IMod
    {
        public string Id => "auto-fishing";
        public string Name => "Auto Fishing";
        public string Version => "1.0.0";

        private static ILogger _log;
        private static ModContext _context;
        private static Harmony _harmony;
        private static Timer _patchTimer;
        private static int _initDelayFrames = 300;
        private static AutoFishingConfig _config;

        // Config (cached for perf)
        internal static bool Enabled = true;
        internal static bool AutoCast = true;
        internal static bool AutoReel = true;
        internal static bool SkipCommonCatches = false;
        internal static int RecastDelayFrames = 120;
        internal static int PullDelayFrames = 30;
        internal static bool AutoBuffEnabled = true;
        internal static bool AutoBuffOnlyWhenFishing = true;
        internal static bool AutoFishingPotion = true;
        internal static bool AutoSonarPotion = true;
        internal static bool AutoCratePotion = true;

        public void Initialize(ModContext context)
        {
            _context = context;
            _log = context.Logger;
            _config = context.GetConfig<AutoFishingConfig>();

            LoadConfig();

            _log.Info("Auto Fishing initializing...");

            try
            {
                _harmony = new Harmony("com.terrariamodder.autofishing");

                context.RegisterKeybind("toggle", "Toggle Auto Fishing", "Toggle auto-fishing on or off", "None", OnToggle);
                context.RegisterKeybind("drink-buffs", "Drink Fishing Potions", "Immediately drink all fishing potions (Fishing, Sonar, Crate)", "None", OnDrinkBuffs);

                _patchTimer = new Timer(PatchAfterDelay, null, 5000, Timeout.Infinite);
                _log.Info("Patches will be applied after 5 seconds...");
            }
            catch (Exception ex)
            {
                _log.Error($"Init failed: {ex.Message}");
            }
        }

        private static void PatchAfterDelay(object state)
        {
            try
            {
                _log?.Info("Applying patches now...");

                var itemCheckMethod = typeof(Player).GetMethod("ItemCheck", BindingFlags.Public | BindingFlags.Instance, null, new Type[0], null);
                var itemCheckPrefix = typeof(FishingEngine).GetMethod("ItemCheckPrefix", BindingFlags.Public | BindingFlags.Static);

                if (itemCheckMethod != null && itemCheckPrefix != null)
                {
                    _harmony.Patch(itemCheckMethod, prefix: new HarmonyMethod(itemCheckPrefix));
                    _log?.Info("Patched Player.ItemCheck (prefix) for auto-cast/reel");
                }
                else
                {
                    _log?.Error($"Failed to find ItemCheck patch targets - Method: {itemCheckMethod != null}, Prefix: {itemCheckPrefix != null}");
                }

                var updateMethod = typeof(Player).GetMethod("Update", new Type[] { typeof(int) });
                var updatePostfix = typeof(FishingEngine).GetMethod("PlayerUpdatePostfix", BindingFlags.Public | BindingFlags.Static);

                if (updateMethod != null && updatePostfix != null)
                {
                    _harmony.Patch(updateMethod, postfix: new HarmonyMethod(updatePostfix));
                    _log?.Info("Patched Player.Update (postfix) for auto-buff");
                }
                else
                {
                    _log?.Error($"Failed to find Update patch targets - Method: {updateMethod != null}, Postfix: {updatePostfix != null}");
                }

                FishingEngine.Initialize(_log);
            }
            catch (Exception ex)
            {
                _log?.Error($"Delayed patch error: {ex.Message}");
            }
        }

        private void LoadConfig()
        {
            if (_config == null) return;
            Enabled = _config.Enabled;
            AutoCast = _config.AutoCast;
            AutoReel = _config.AutoReel;
            SkipCommonCatches = _config.SkipCommonCatches;
            RecastDelayFrames = _config.RecastDelayFrames;
            PullDelayFrames = _config.PullDelayFrames;
            AutoBuffEnabled = _config.AutoBuffEnabled;
            AutoBuffOnlyWhenFishing = _config.AutoBuffOnlyWhenFishing;
            AutoFishingPotion = _config.AutoFishingPotion;
            AutoSonarPotion = _config.AutoSonarPotion;
            AutoCratePotion = _config.AutoCratePotion;
        }

        public void OnConfigChanged()
        {
            LoadConfig();
            _log.Info($"Config reloaded - Enabled:{Enabled} Cast:{AutoCast} Reel:{AutoReel} SkipCommon:{SkipCommonCatches}");
        }

        private void OnToggle()
        {
            Enabled = !Enabled;
            if (_config != null) { _config.Enabled = Enabled; _config.Save(); }
            _log.Info($"Auto Fishing: {(Enabled ? "ON" : "OFF")}");
            if (Enabled)
            {
                FishingEngine.Reset();
            }
        }

        public void OnContentReady(ModContext context) { }

        public void OnWorldLoad()
        {
            _initDelayFrames = 300;
            FishingEngine.Reset();
            _log.Info("World loaded - fishing engine reset");
        }

        public void OnWorldUnload()
        {
            FishingEngine.Reset();
        }

        public void Unload()
        {
            _patchTimer?.Dispose();
            _harmony?.UnpatchAll("com.terrariamodder.autofishing");
            _patchTimer = null;
            _log.Info("Auto Fishing unloaded");
        }

        /// <summary>
        /// Tick the init delay counter. Called from PlayerUpdatePostfix only (once per frame)
        /// to avoid double-decrement when both patches call it.
        /// </summary>
        internal static void TickInitDelay()
        {
            if (_initDelayFrames > 0)
            {
                _initDelayFrames--;
                if (_initDelayFrames == 0)
                {
                    FishingEngine.SetInitReady();
                    _log?.Info("Init delay complete, fishing engine active");
                }
            }
        }

        private void OnDrinkBuffs()
        {
            if (Main.gameMenu) return;
            Player player = Main.player[Main.myPlayer];
            FishingEngine.DrinkAllFishingPotions(player);
            _log.Info("Manually triggered fishing potion buffs");
        }

        internal static void Log(string message) => _log?.Info(message);
        internal static void LogDebug(string message) => _log?.Debug(message);
    }
}

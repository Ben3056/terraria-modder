using TerrariaModder.Core.Config;

namespace AssetExperienceMod
{
    public class AssetExperienceModConfig : ModConfig
    {
        public override int Version => 1;

        [Client, Label("Enabled"), Description("Load custom test items with extreme stats for testing the asset system. Spawn them via NumPad keybinds.")]
        public bool Enabled { get; set; } = true;
    }
}

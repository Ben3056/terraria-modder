using System;
using System.Collections.Generic;
using System.Reflection;
using Terraria;
using TerrariaModder.Core;
using TerrariaModder.Core.Assets;
using TerrariaModder.Core.Logging;

namespace AssetExperienceMod
{
    /// <summary>
    /// Manual testing mod for the v3 Custom Assets system.
    ///
    /// Registers items with DRAMATIC stats for obvious effects:
    /// - 200+ damage weapons
    /// - 50+ defense armor
    /// - 15+ knockback
    ///
    /// Items get real runtime type IDs (6145+) and behave identically to vanilla.
    /// Custom textures loaded from assets/textures/*.png.
    /// </summary>
    public class Mod : IMod
    {
        public string Id => "asset-experience-mod";
        public string Name => "Asset Experience Mod";
        public string Version => "2.0.0";

        private ILogger _log;
        private ModContext _context;
        private bool _enabled;
        private AssetExperienceModConfig _config;

        // Throttle counters for per-frame hooks (avoid log spam)
        private int _updateEquipLogCounter;
        private int _onHoldLogCounter;

        public void Initialize(ModContext context)
        {
            _context = context;
            _log = context.Logger;
            _config = context.GetConfig<AssetExperienceModConfig>();

            _enabled = _config != null ? _config.Enabled : true;
            if (!_enabled)
            {
                _log.Info("Asset Experience Mod is disabled in config");
                return;
            }

            RegisterItems();
            RegisterRecipes();
            RegisterShopItems();
            RegisterDrops();

            // Keybinds to spawn groups of items via SetDefaults
            context.RegisterKeybind("spawn-melee", "Spawn Melee",
                "Spawn melee weapons to inventory", "NumPad1", OnSpawnMelee);
            context.RegisterKeybind("spawn-ranged", "Spawn Ranged",
                "Spawn ranged weapons to inventory", "NumPad2", OnSpawnRanged);
            context.RegisterKeybind("spawn-consumables", "Spawn Consumables",
                "Spawn consumables to inventory", "NumPad3", OnSpawnConsumables);
            context.RegisterKeybind("spawn-armor", "Spawn Armor",
                "Spawn full armor set", "NumPad4", OnSpawnArmor);
            context.RegisterKeybind("spawn-all", "Spawn All",
                "Spawn all test items", "NumPad5", OnSpawnAll);
            context.RegisterKeybind("log-inventory", "Log Inventory",
                "Log modded items in inventory", "NumPad0", OnLogInventory);

            // Debug commands for testing item protection (sort/quickstack via API)
            context.RegisterCommand("sort", "Trigger inventory sort (tests item protection)", args => OnTestSort());
            context.RegisterCommand("quickstack", "Trigger quick stack (tests item protection)", args => OnTestQuickStack());
            context.RegisterCommand("spawn", "Spawn all test items", args => OnSpawnAll());
            context.RegisterCommand("log-inventory", "Log modded items in inventory", args => OnLogInventory());
            context.RegisterCommand("dump-state", "Dump player movement state for debugging", args => OnDumpState());

            _log.Info("Asset Experience Mod v2.0 initialized (v3 asset system)");
            _log.Info("  Items get real type IDs - behave identically to vanilla");
            _log.Info("  NumPad1=Melee  NumPad2=Ranged  NumPad3=Consumables");
            _log.Info("  NumPad4=Armor  NumPad5=All     NumPad0=Log Inventory");
        }

        private void RegisterItems()
        {
            // ── MELEE WEAPONS ──

            _context.RegisterItem("power-sword", new ItemDefinition
            {
                DisplayName = "Power Test Sword",
                Tooltip = new[] { "Extreme damage test sword", "Custom fire texture", "+100 bonus damage from ModifyWeaponDamage" },
                Texture = "assets/textures/tx_sword_fire.png",
                Damage = 500,
                KnockBack = 15f,
                UseTime = 20,
                UseAnimation = 20,
                UseStyle = 1, // Swing
                Melee = true,
                AutoReuse = true,
                Width = 40,
                Height = 40,
                Rarity = 11,
                Value = 1000000,
                // Hook: log hits and add +100 bonus damage
                OnHitNPC = (player, npc, damage, kb, crit) =>
                {
                    _log.Info($"[PowerSword] OnHitNPC! damage={damage} kb={kb} crit={crit}");
                },
                ModifyWeaponDamage = (object player, ref int damage) =>
                {
                    damage += 100;
                },
                OnHoldItem = (player) =>
                {
                    _onHoldLogCounter++;
                    if (_onHoldLogCounter % 300 == 0)
                        _log.Info($"[PowerSword] OnHoldItem tick #{_onHoldLogCounter}");
                }
            });

            _context.RegisterItem("ice-sword", new ItemDefinition
            {
                DisplayName = "Ice Test Sword (BROKEN)",
                Tooltip = new[] { "Ice themed sword", "BROKEN: CanUseItem returns false" },
                Texture = "assets/textures/tx_sword_ice.png",
                Damage = 300,
                KnockBack = 12f,
                UseTime = 18,
                UseAnimation = 18,
                UseStyle = 1,
                Melee = true,
                AutoReuse = true,
                Width = 40,
                Height = 40,
                Rarity = 9,
                Value = 500000,
                // Hook: always block use
                CanUseItem = (player) => false
            });

            // ── RANGED WEAPONS ──

            _context.RegisterItem("shadow-bow", new ItemDefinition
            {
                DisplayName = "Shadow Bow",
                Tooltip = new[] { "Shadow themed bow", "Uses arrows as ammo", "OnShoot: fires Jester Arrows (proj 5)" },
                Texture = "assets/textures/tx_bow_shadow.png",
                Damage = 400,
                KnockBack = 8f,
                UseTime = 15,
                UseAnimation = 15,
                UseStyle = 5, // Bow style
                Ranged = true,
                AutoReuse = true,
                UseAmmo = 40, // Arrow ammo type
                Shoot = 1, // Arrow projectile (overridden by ammo)
                ShootSpeed = 12f,
                Width = 20,
                Height = 40,
                Rarity = 9,
                Value = 800000,
                // Hook: override projectile to Jester Arrow (proj ID 5)
                OnShoot = (player, origProj, speed) => 5
            });

            _context.RegisterItem("plasma-gun", new ItemDefinition
            {
                DisplayName = "Plasma Gun",
                Tooltip = new[] { "Sci-fi gun", "Uses bullets", "OnHoldItem + ModifyTooltips active" },
                Texture = "assets/textures/tx_gun_plasma.png",
                Damage = 350,
                KnockBack = 4f,
                UseTime = 12,
                UseAnimation = 12,
                UseStyle = 5,
                Ranged = true,
                AutoReuse = true,
                UseAmmo = 97, // Bullet ammo (Musket Ball)
                Shoot = 14, // Bullet projectile
                ShootSpeed = 16f,
                NoMelee = true,
                Width = 40,
                Height = 20,
                Rarity = 9,
                Value = 700000,
                // Hook: log when held (throttled)
                OnHoldItem = (player) =>
                {
                    _onHoldLogCounter++;
                    if (_onHoldLogCounter % 300 == 0)
                        _log.Info($"[PlasmaGun] OnHoldItem tick #{_onHoldLogCounter}");
                },
                // Hook: add dynamic lines to tooltip
                ModifyTooltips = (lines) =>
                {
                    try
                    {
                        double time = Main.time;
                        bool day = Main.dayTime;
                        lines.Add($"Game time: {(day ? "Day" : "Night")} {time:F0}");
                        bool holding = Main.player[Main.myPlayer]?.HeldItem?.type == 6153;
                        lines.Add($"Holding: {(holding ? "yes" : "no")}");
                    }
                    catch { }
                }
            });

            // ── CONSUMABLES ──

            _context.RegisterItem("red-potion", new ItemDefinition
            {
                DisplayName = "Red Test Potion (Eternal)",
                Tooltip = new[] { "Gives Ironskin for 60s", "ETERNAL: OnConsume returns false" },
                Texture = "assets/textures/tx_potion_red.png",
                Consumable = true,
                MaxStack = 99,
                UseStyle = 2, // Drink
                UseTime = 17,
                UseAnimation = 17,
                Potion = true,
                BuffType = 5, // Ironskin
                BuffTime = 3600,
                Width = 20,
                Height = 26,
                Rarity = 2,
                Value = 1000,
                // Hook: never consume the item
                OnConsume = (player) => false
            });

            _context.RegisterItem("blue-potion", new ItemDefinition
            {
                DisplayName = "Blue Test Potion",
                Tooltip = new[] { "Gives Wrath (+10% damage)", "OnUse: logs when used" },
                Texture = "assets/textures/tx_potion_blue.png",
                Consumable = true,
                MaxStack = 99,
                UseStyle = 2,
                UseTime = 17,
                UseAnimation = 17,
                Potion = true,
                BuffType = 117, // Wrath
                BuffTime = 3600,
                Width = 20,
                Height = 26,
                Rarity = 6,
                Value = 5000,
                // Hook: log on use
                OnUse = (player) =>
                {
                    _log.Info("[BluePotion] OnUse fired!");
                    return true; // allow use
                }
            });

            _context.RegisterItem("green-potion", new ItemDefinition
            {
                DisplayName = "Green Test Potion",
                Tooltip = new[] { "Gives Regeneration for 60s" },
                Texture = "assets/textures/tx_potion_green.png",
                Consumable = true,
                MaxStack = 99,
                UseStyle = 2,
                UseTime = 17,
                UseAnimation = 17,
                Potion = true,
                BuffType = 2, // Regeneration
                BuffTime = 3600,
                Width = 20,
                Height = 26,
                Rarity = 3,
                Value = 2000
            });

            // ── ARMOR ──

            _context.RegisterItem("dragon-helmet", new ItemDefinition
            {
                DisplayName = "Dragon Helmet",
                Tooltip = new[] { "+50 defense", "Test armor head slot" },
                Texture = "assets/textures/tx_helm_dragon.png",
                Defense = 50,
                HeadSlot = 1, // Borrows Iron Helmet visuals
                Width = 20,
                Height = 20,
                Rarity = 5,
                Value = 500000
            });

            _context.RegisterItem("dragon-chestplate", new ItemDefinition
            {
                DisplayName = "Dragon Chestplate",
                Tooltip = new[] { "+60 defense", "Test armor body slot" },
                Texture = "assets/textures/tx_chest_dragon.png",
                Defense = 60,
                BodySlot = 1, // Borrows Iron Chestplate visuals
                Width = 20,
                Height = 20,
                Rarity = 5,
                Value = 600000
            });

            _context.RegisterItem("dragon-leggings", new ItemDefinition
            {
                DisplayName = "Dragon Leggings",
                Tooltip = new[] { "+50 defense", "Test armor legs slot" },
                Texture = "assets/textures/tx_legs_dragon.png",
                Defense = 50,
                LegSlot = 1, // Borrows Iron Greaves visuals
                Width = 20,
                Height = 20,
                Rarity = 5,
                Value = 500000
            });

            // ── ACCESSORIES ──

            _context.RegisterItem("emerald-amulet", new ItemDefinition
            {
                DisplayName = "Emerald Amulet",
                Tooltip = new[] { "Test accessory", "Custom emerald texture", "UpdateEquip: logs every 300 frames" },
                Texture = "assets/textures/tx_amulet_emerald.png",
                Accessory = true,
                Width = 20,
                Height = 20,
                Rarity = 8,
                Value = 500000,
                // Hook: log periodically while equipped
                UpdateEquip = (player) =>
                {
                    _updateEquipLogCounter++;
                    if (_updateEquipLogCounter % 300 == 0)
                        _log.Info($"[EmeraldAmulet] UpdateEquip tick #{_updateEquipLogCounter}");
                }
            });

            // ── MATERIALS ──

            _context.RegisterItem("mythril-ore", new ItemDefinition
            {
                DisplayName = "Custom Mythril Ore",
                Tooltip = new[] { "Stackable test material", "Used in recipes" },
                Texture = "assets/textures/tx_ore_mythril.png",
                MaxStack = 9999,
                Material = true,
                Width = 20,
                Height = 20,
                Rarity = 3,
                Value = 1000
            });

            _context.RegisterItem("shadow-ore", new ItemDefinition
            {
                DisplayName = "Shadow Ore",
                Tooltip = new[] { "Dark stackable material" },
                Texture = "assets/textures/tx_ore_shadow.png",
                MaxStack = 9999,
                Material = true,
                Width = 20,
                Height = 20,
                Rarity = 5,
                Value = 5000
            });

            _log.Info("Registered 13 test items");
        }

        private void RegisterRecipes()
        {
            // Power Sword: 10 Iron Bars + 5 Gel @ Anvil
            _context.RegisterRecipe(new RecipeDefinition
            {
                Result = $"{Id}:power-sword",
                ResultStack = 1,
                Ingredients = { { "IronBar", 10 }, { "Gel", 5 } },
                Station = "Anvils"
            });

            // Red Potion: 1 Bottled Water + 1 Gel @ Bottles
            _context.RegisterRecipe(new RecipeDefinition
            {
                Result = $"{Id}:red-potion",
                ResultStack = 3,
                Ingredients = { { "28", 1 }, { "23", 1 } }, // Lesser Healing + Gel
                Station = "Bottles"
            });

            _log.Info("Registered 2 recipes");
        }

        private void RegisterShopItems()
        {
            // Emerald Amulet from Merchant - 10 gold
            _context.AddShopItem(new ShopDefinition
            {
                NpcType = 17, // Merchant
                ItemId = $"{Id}:emerald-amulet",
                Price = 100000
            });

            _log.Info("Registered 1 shop item");
        }

        private void RegisterDrops()
        {
            // Mythril Ore from Blue Slime - 25%
            _context.RegisterDrop(new DropDefinition
            {
                NpcType = 1, // Blue Slime
                ItemId = $"{Id}:mythril-ore",
                Chance = 0.25f,
                MinStack = 1,
                MaxStack = 3
            });

            _log.Info("Registered 1 drop");
        }

        // ── Item Spawning ──
        // v3: items have real type IDs, spawn via SetDefaults

        private void SpawnItem(string itemName)
        {
            var player = Main.LocalPlayer;
            if (player == null || player.dead) return;

            string fullId = $"{Id}:{itemName}";
            int runtimeType = ItemRegistry.GetRuntimeType(fullId);
            if (runtimeType < 0)
            {
                _log.Warn($"Cannot resolve: {fullId}");
                return;
            }

            // Find empty inventory slot
            for (int i = 0; i < 50; i++)
            {
                if (player.inventory[i] == null || player.inventory[i].type == 0 || player.inventory[i].IsAir)
                {
                    player.inventory[i] = new Item();
                    player.inventory[i].SetDefaults(runtimeType);
                    _log.Info($"  Spawned {itemName} (type {runtimeType}) in slot {i}");
                    return;
                }
            }
            _log.Warn($"  No empty slot for {itemName}");
        }

        private void OnSpawnMelee()
        {
            if (!_enabled) return;
            _log.Info("=== Spawning MELEE weapons ===");
            SpawnItem("power-sword");
            SpawnItem("ice-sword");
        }

        private void OnSpawnRanged()
        {
            if (!_enabled) return;
            _log.Info("=== Spawning RANGED weapons ===");
            SpawnItem("shadow-bow");
            SpawnItem("plasma-gun");
        }

        private void OnSpawnConsumables()
        {
            if (!_enabled) return;
            _log.Info("=== Spawning CONSUMABLES ===");
            SpawnItem("red-potion");
            SpawnItem("blue-potion");
            SpawnItem("green-potion");
        }

        private void OnSpawnArmor()
        {
            if (!_enabled) return;
            _log.Info("=== Spawning ARMOR + ACCESSORIES ===");
            SpawnItem("dragon-helmet");
            SpawnItem("dragon-chestplate");
            SpawnItem("dragon-leggings");
            SpawnItem("emerald-amulet");
        }

        private void OnSpawnAll()
        {
            if (!_enabled) return;
            _log.Info("=== Spawning ALL items ===");
            SpawnItem("power-sword");
            SpawnItem("ice-sword");
            SpawnItem("shadow-bow");
            SpawnItem("plasma-gun");
            SpawnItem("red-potion");
            SpawnItem("blue-potion");
            SpawnItem("green-potion");
            SpawnItem("dragon-helmet");
            SpawnItem("dragon-chestplate");
            SpawnItem("dragon-leggings");
            SpawnItem("emerald-amulet");
            SpawnItem("mythril-ore");
            SpawnItem("shadow-ore");
        }

        private void OnLogInventory()
        {
            if (!_enabled) return;
            var player = Main.LocalPlayer;
            if (player == null || player.dead) return;

            _log.Info("=== MODDED ITEMS IN INVENTORY ===");
            int found = 0;

            for (int i = 0; i < 50; i++)
            {
                var item = player.inventory[i];
                if (item == null || item.type == 0 || item.IsAir) continue;

                if (ItemRegistry.IsCustomItem(item.type))
                {
                    string fullId = ItemRegistry.GetFullId(item.type);
                    var def = ItemRegistry.GetDefinition(item.type);
                    _log.Info($"  Slot {i}: {def?.DisplayName ?? "?"} ({fullId}) type={item.type} stack={item.stack}");
                    found++;
                }
            }

            _log.Info(found == 0 ? "  No modded items found" : $"=== TOTAL: {found} modded items ===");
        }

        // ── Test Commands (invoked via POST /api/execute) ──

        private void OnTestSort()
        {
            if (!_enabled) return;
            var player = Main.LocalPlayer;
            if (player == null || player.dead) return;

            _log.Info("=== TESTING SORT (item protection) ===");
            OnLogInventory(); // Log before

            try
            {
                // Call ItemSorting.Sort via reflection
                var sortingType = typeof(Main).Assembly.GetType("Terraria.UI.ItemSorting");
                if (sortingType == null)
                {
                    _log.Warn("ItemSorting type not found");
                    return;
                }

                var sortMethod = sortingType.GetMethod("Sort",
                    System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static, null,
                    new[] { typeof(bool), typeof(Item[]), typeof(int[]) }, null);

                if (sortMethod == null)
                {
                    _log.Warn("ItemSorting.Sort not found");
                    return;
                }

                // Match vanilla: ignore hotbar (0-9) and coins/ammo (50-58)
                sortMethod.Invoke(null, new object[] { false, player.inventory,
                    new[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 50, 51, 52, 53, 54, 55, 56, 57, 58 } });
                _log.Info("Sort complete");
            }
            catch (Exception ex)
            {
                var inner = ex.InnerException ?? ex;
                _log.Error($"Sort failed: {inner.GetType().Name}: {inner.Message}");
                _log.Error($"Sort stack: {inner.StackTrace}");
            }

            OnLogInventory(); // Log after
        }

        private void OnTestQuickStack()
        {
            if (!_enabled) return;
            var player = Main.LocalPlayer;
            if (player == null || player.dead) return;

            _log.Info("=== TESTING QUICKSTACK (item protection) ===");
            OnLogInventory(); // Log before

            try
            {
                player.QuickStackAllChests();
                _log.Info("QuickStack complete");
            }
            catch (Exception ex)
            {
                _log.Error($"QuickStack failed: {ex.Message}");
            }

            OnLogInventory(); // Log after
        }

        private void OnDumpState()
        {
            var p = Main.LocalPlayer;
            if (p == null) return;

            _log.Info("=== PLAYER STATE DUMP ===");
            _log.Info($"  velocity={p.velocity} position={p.position}");
            _log.Info($"  controlLeft={p.controlLeft} controlRight={p.controlRight} controlUp={p.controlUp} controlDown={p.controlDown} controlJump={p.controlJump}");
            _log.Info($"  frozen={p.frozen} webbed={p.webbed} stoned={p.stoned} noItems={p.noItems}");
            _log.Info($"  mount.Active={p.mount?.Active} gravDir={p.gravDir} dead={p.dead}");
            _log.Info($"  maxRunSpeed={p.maxRunSpeed} accRunSpeed={p.accRunSpeed} moveSpeed={p.moveSpeed}");
            _log.Info($"  head={p.head} body={p.body} legs={p.legs}");

            // Log armor slots
            for (int i = 0; i < 3; i++)
            {
                var a = p.armor[i];
                if (a != null && !a.IsAir)
                    _log.Info($"  armor[{i}]: type={a.type} headSlot={a.headSlot} bodySlot={a.bodySlot} legSlot={a.legSlot} defense={a.defense} useTime={a.useTime} useStyle={a.useStyle}");
            }

            // Check HeldItem
            var held = p.HeldItem;
            if (held != null)
                _log.Info($"  HeldItem: type={held.type} useTime={held.useTime} useStyle={held.useStyle} channel={held.channel}");

            _log.Info($"  selectedItem={p.selectedItem} itemAnimation={p.itemAnimation} itemTime={p.itemTime}");
            _log.Info($"  pulley={p.pulley} tongued={p.tongued} CCed={p.CCed}");
        }

        public void OnContentReady(ModContext context) { }

        public void OnWorldLoad() { }
        public void OnWorldUnload() { }

        public void Unload()
        {
            _log?.Info("Asset Experience Mod unloaded");
        }

        public void OnConfigChanged()
        {
            bool wasEnabled = _enabled;
            _enabled = _config != null ? _config.Enabled : true;
            if (wasEnabled != _enabled)
                _log.Info($"Asset Experience Mod is now {(_enabled ? "enabled" : "disabled")}");
        }
    }
}
